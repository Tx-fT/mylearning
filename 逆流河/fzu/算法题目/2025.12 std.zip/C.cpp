#include<bits/stdc++.h>

using namespace std;

#define ULL unsigned long long
#define int long long
#define endl '\n'
typedef pair<int, int> pii;

int n,k;

void solve(){
    cin>>n>>k;

    double maxn=0;

    for(int i=1;i<=n;i++){
        double now=(k+i)/(i+1)*i-k+1.0*k/(i+1);
        maxn=max(now,maxn);
    }

    cout<<fixed<<setprecision(2)<<maxn<<endl;
}

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    int T=1;
    // cin>>T;
    while(T--){
        solve();
    }
}