#include <bits/stdc++.h>

using i64 = long long;

#define debug(a) std::cout << #a << '=' << (a) << ' '

template <class T>
inline void chmin(T &x, const T &y) {
    if (x > y) {
        x = y;
    }
}
template <class T>
inline void chmax(T &x, const T &y) {
    if (x < y) {
        x = y;
    }
}

const int N = 200100;

int n, k;
int a[N];

void work() {
    std::cin >> n >> k;

    int mx = 0;
    for (int i = 1; i <= n; i ++) {
        std::cin >> a[i];
        chmax(mx, a[i]);
    }

    int l = mx, r = mx + k - 1;
    for (int i = 1; i <= n; i ++) {
        int step = (mx - a[i] + 2 * k - 1) / (2 * k);
        int x = a[i] + step * (2 * k);

        if (x <= mx + k - 1) {
            chmax(l, x);
        } else {
            chmin(r, x - k - 1);
        }
    }

    if (l <= r) {
        std::cout << l << '\n';
    } else {
        std::cout << -1 << '\n';
    }
}

int main() {
    std::ios::sync_with_stdio(0);
    std::cin.tie(0);

    int T;
    std::cin >> T;

    while (T --) {
        work();
    }

    return 0;
}