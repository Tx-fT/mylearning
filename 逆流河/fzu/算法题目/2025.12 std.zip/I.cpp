#include <bits/stdc++.h>

using i64 = long long;

#define debug(a) std::cout << #a << '=' << (a) << ' '

template <class T>
inline void chmin(T &x, const T &y) {
    if (x > y) {
        x = y;
    }
}
template <class T>
inline void chmax(T &x, const T &y) {
    if (x < y) {
        x = y;
    }
}

const int N = 200100;
const i64 inf = 1e18;

int n;
std::pair<int, int> seq[N];

struct trans {
    i64 a, b;
    trans() {}
    trans(i64 _a, i64 _b) : a(_a), b(_b) {}

    friend trans operator + (trans lhs, trans rhs) {
        return trans(std::max(lhs.a, rhs.a - lhs.b), lhs.b + rhs.b);
    }

    i64 calc(i64 x) {
        return std::max(x, a) + b;
    }
} pre[N], suf[N];

void work() {
    std::cin >> n;

    for (int i = 1; i <= n; i ++) {
        i64 t, d;
        std::cin >> t >> d;
        seq[i] = {t, d};
    }

    std::sort(seq + 1, seq + 1 + n);

    pre[0] = trans(0, 0);
    for (int i = 1; i <= n; i ++) {
        auto [t, d] = seq[i];
        pre[i] = pre[i - 1] + trans(t, d * 2);
    }

    suf[n + 1] = trans(0, 0);
    for (int i = n; i >= 1; i --) {
        auto [t, d] = seq[i];
        suf[i] = trans(t, d * 2) + suf[i + 1];
    }

    i64 ans = inf;
    for (int i = 1; i <= n; i ++) {
        auto [t, d] = seq[i];
        i64 x = 0;
        x = pre[i - 1].calc(x); // debug(i), debug(x) << '\n';
        x = suf[i + 1].calc(x); // debug(i), debug(x) << '\n';
        x = trans(t, d).calc(x); // debug(i), debug(x) << '\n';
        chmin(ans, x);
    }

    std::cout << ans << '\n';
}

int main() {
    std::ios::sync_with_stdio(0);
    std::cin.tie(0);

    int T;
    std::cin >> T;

    while (T --) {
        work();
    }

    return 0;
}

/*
1
5
1 4
2 3
8 1
8 3
12 2
*/