#include <bits/stdc++.h>

using i64 = long long;

#define debug(a) std::cout << #a << '=' << (a) << ' '

template <class T>
inline void chmin(T &x, const T &y) {
    if (x > y) {
        x = y;
    }
}
template <class T>
inline void chmax(T &x, const T &y) {
    if (x < y) {
        x = y;
    }
}

void work() {
    int n, m;
    std::cin >> n >> m;

    if (n > m) {
        std::swap(n, m);
    }

    if (n == 1) {
        std::cout << 1 << '\n';
    } else if (n == 2) {
        std::cout << ((m + 1) / 2) << '\n';
    } else if (n == 3 && m == 3) {
        std::cout << 8 << '\n';
    } else {
        std::cout << (1ll * n * m) << '\n';
    }
}

int main() {
    std::ios::sync_with_stdio(0);
    std::cin.tie(0);

    int T;
    std::cin >> T;

    while (T --) {
        work();
    }

    return 0;
}