#include<bits/stdc++.h>

using namespace std;

#define ULL unsigned long long
#define int long long
#define endl '\n'
typedef pair<int, int> pii;

const int N=2e5+5;
int n,k;
int a[N],v[N];

int check(int mid){
    int j=0,ans=0;
    for(int i=0;i<=n;i++)v[i]=0;
    for(int i=1;i<=n;i++){
        if(a[i]<mid)v[a[i]]=1;
        while(j<mid&&v[j]){
            j++;
        }
        if(j==mid){
            ans++;
            j=0;
            for(int j=0;j<mid;j++){
                v[j]=0;
            }
        }
    }
    return ans>=k;
}

void solve(){
    cin>>n>>k;

    for(int i=1;i<=n;i++)cin>>a[i];

    int l=-1,r=n+1;
    while(l+1<r){
        int mid=(l+r)>>1;
        if(check(mid)){
            l=mid;
        }else{
            r=mid;
        }
    }

    cout<<l<<endl;
}

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    int T=1;
    // cin>>T;
    while(T--){
        solve();
    }
}