#include <bits/stdc++.h>

int main() {
    int n;
    std::cin >> n;

    std::cout << "IL0V3F2U4CM2O25" << '\n';
    return 0;
}