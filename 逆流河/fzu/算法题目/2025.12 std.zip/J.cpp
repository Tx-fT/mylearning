#include<iostream>
#include<cstring>
using std::cin,std::cout;
int n,i,j;
const int N=25;
int f[1<<N|10],vis[1<<N|10];
int st[1<<N|10];
int tp=0;
void dfs(int x){
    if(f[x]!=-1)return ;
    if(vis[x]!=-1){
        int y;
        int gg=tp+1-vis[x];
        do{
            y=st[tp];
            vis[y]=-1;
            f[y]=gg;
            tp--;
        }
        while(y!=x);
        return ;
    }
    st[++tp]=x;
    vis[x]=tp;
    int y=(x>>1)|(((x>>(n-i-1)&1)&(x>>(n-j-1)&1)&((x&1)^1))<<n-1);
    dfs(y);
    if(f[x]==-1)f[x]=f[y]+1;
    vis[x]=-1;
    return ;
}
int main(){
    cin>>n>>i>>j;
    memset(vis,-1,sizeof vis);
    memset(f,-1,sizeof f);
    long long ans=0;
    for(int i=0;i<1<<n;i++){
        tp=0,dfs(i),ans+=f[i];
    }
    cout<<ans<<'\n';
    return 0;
}