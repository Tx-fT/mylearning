#include <bits/stdc++.h>

using i64 = long long;

#define debug(a) std::cout << #a << '=' << (a) << ' '

template <class T>
inline void chmin(T &x, const T &y) {
    if (x > y) {
        x = y;
    }
}
template <class T>
inline void chmax(T &x, const T &y) {
    if (x < y) {
        x = y;
    }
}

const int N = 200100;

int n;
int a[N];

void work() {
    std::cin >> n;

    int cnt[2] = {0, 0};
    for (int i = 1; i <= n; i ++) {
        std::cin >> a[i];
        cnt[a[i] & 1] ++;
    }

    int mx = 0;
    i64 sum = 0;
    for (int i = 1; i <= n; i ++) {
        chmax(mx, a[i]);
        sum += a[i];
    }

    if (cnt[0] && cnt[1]) {
        std::cout << (sum - cnt[1] + 1) << '\n';
    } else {
        std::cout << mx << '\n';
    }
}

int main() {
    std::ios::sync_with_stdio(0);
    std::cin.tie(0);

    int T;
    std::cin >> T;

    while (T --) {
        work();
    }

    return 0;
}