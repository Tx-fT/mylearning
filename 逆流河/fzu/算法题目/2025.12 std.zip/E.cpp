#include <bits/stdc++.h>

using i64 = long long;

#define debug(a) std::cout << #a << '=' << (a) << ' '

template <class T>
inline void chmin(T &x, const T &y) {
    if (x > y) {
        x = y;
    }
}
template <class T>
inline void chmax(T &x, const T &y) {
    if (x < y) {
        x = y;
    }
}


const int N = 100100;

int n, k;

int main() {
    std::ios::sync_with_stdio(0);
    std::cin.tie(0);

    std::cin >> n >> k;

    if (n == 1) {
        std::cout << "YES\n";
        std::cout << 1 << '\n';
        return 0;
    }
    if (n == 2 || n == 3) {
        std::cout << "NO\n";
        return 0;
    }

    if (k == 2) {
        std::cout << "NO\n";
        return 0;
    }

    std::vector<int> ans;
    if (n % 4 == 0) {
        ans = {2, 4, 1, 3};
    } else if (n % 4 == 1) {
        ans = {1, 3, 5, 2, 4};
    } else if (n % 4 == 2) {
        ans = {1, 3, 6, 4, 2, 5};
    } else if (n % 4 == 3) {
        ans = {2, 5, 7, 4, 1, 3, 6};
    }

    int st = 4 + n % 4;
    while (st < n) {
        ans.push_back(st + 2);
        ans.push_back(st + 4);
        ans.push_back(st + 1);
        ans.push_back(st + 3);
        st += 4;
    }

    std::cout << "YES\n";
    for (int x : ans) {
        std::cout << x << ' ';
    }
    std::cout << '\n';

    return 0;
}