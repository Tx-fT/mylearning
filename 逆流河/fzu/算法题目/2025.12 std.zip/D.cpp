#include<iostream>
#include<queue>
#include<algorithm>
using std::cin,std::cout;
const int N=10010;
const int M=8;
int power[N][3];
int vis[M+1][6];
int shop[M+1][6];
int life[N];
std::queue<int>q;
int n;
struct node{
    int st[22];
    int get_size(){
        int ans=0;
        for(int i=1;i<=n;i++){
            int x=st[i];
            ans+=x/9,x%=9;
            ans+=x/3,x%=3;
            ans+=x;
        }
        return ans;
    }
    void insert(int x){
        st[x]++;
    }
    int get_power(){
        int ans=0;
        for(int i=1;i<=n;i++){
            int x=st[i];
            ans+=(x/9)*power[i][2],x%=9;
            ans+=(x/3)*power[i][1],x%=3;
            ans+=(x)*power[i][0];
        }
        return ans;
    }
}a[9];
void fresh(int id){
    for(int i=1;i<=5;i++){
        if(vis[id][i]){
            q.push(shop[id][i]);
        }
    }
    for(int i=1;i<=5;i++){
        vis[id][i]=1;
        int u=q.front();
        q.pop();
        shop[id][i]=u;
    }
}
int p[9];
void work(){
    while(!q.empty()){
        q.pop();
    }
    cin>>n;
    for(int i=1;i<=8;i++){
        for(int j=1;j<=n;j++)a[i].st[j]=0;
    }
    for(int i=1;i<=n;i++)for(int j=0;j<3;j++)cin>>power[i][j];
    int L;
    cin>>L;
    for(int i=1;i<=L;i++){
        int x;
        cin>>x;
        q.push(x);
    }
    for(int i=1;i<=M;i++){ 
        for(int j=1;j<=5;j++){
            cin>>shop[i][j];
            vis[i][j]=1;
        }
    }
    int Q;
    cin>>Q;
    for(int i=1;i<=M;i++)life[i]=100;
    while(Q--){
        int kill;
        cin>>kill;
        int m;
        cin>>m;
        for(int i=1;i<=m;i++){
            int id;
            cin>>id;
            std::string s;
            cin>>s;
            if(s[0]=='R'&&life[id]>0){
                fresh(id);
            }
            else if(s[0]=='B'){
                int k;
                cin>>k;
                if(vis[id][k]&&life[id]>0){
                    node y=a[id];
                    y.insert(shop[id][k]);
                    if(y.get_size()<=10){
                        a[id].insert(shop[id][k]);
                        vis[id][k]=0;
                    }
                }
            }
        }
        int lst=-1;
        for(int i=1;i<=8;i++)cin>>p[i];
        for(int i=1;i<=8;i++)if(life[p[i]]>0){
            if(lst==-1){
                lst=p[i];
            }
            else {
                int x=a[lst].get_power();
                int y=a[p[i]].get_power();
                if(x==y){
                    life[lst]-=kill,life[p[i]]-=kill;
                }
                else if(x<y){
                    life[lst]-=kill;
                }
                else {
                    life[p[i]]-=kill;
                }
                lst=-1;
            }
        }
    }
    int ans=1;
    if(life[1]<0)life[1]=0;
    for(int i=2;i<=8;i++)if(life[i]>life[ans]){
        ans=i;
        break;
    }
    cout<<ans<<'\n';
}
int main(){
    std::ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    int t;
    cin>>t;
    while(t--)work();
    return 0;
}