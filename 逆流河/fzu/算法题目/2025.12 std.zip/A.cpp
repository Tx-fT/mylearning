#include <bits/stdc++.h>

using i64 = long long;

#define debug(a) std::cout << #a << '=' << (a) << ' '

template <class T>
inline void chmin(T &x, const T &y) {
    if (x > y) {
        x = y;
    }
}
template <class T>
inline void chmax(T &x, const T &y) {
    if (x < y) {
        x = y;
    }
}

int m;
int solved, penalty;
int ok[13], used[13];

int main() {
    std::ios::sync_with_stdio(0);
    std::cin.tie(0);

    std::cin >> m;

    for (int i = 1; i <= m; i ++) {
        std::string problem, time, result;
        std::cin >> problem >> time >> result;

        int p = problem[0] - 'A';
        int t = 60 * (time[0] - '0') + 10 * (time[2] - '0') + (time[3] - '0');
        
        if (ok[p]) { // 已经 AC
            continue;
        }

        if (result[3] == 'R') { // AC
            solved ++;
            penalty += t + used[p];
            ok[p] = 1;
        } else if (result[3] != 'P') { // 不含编译错误的错误提交
            used[p] += 20;
        }
    }

    std::cout << solved << ' ' << penalty << '\n';

    return 0;
}